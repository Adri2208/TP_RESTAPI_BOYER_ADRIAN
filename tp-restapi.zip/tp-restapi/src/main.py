from flask import Flask, request, jsonify, Response
from flask_sqlalchemy import SQLAlchemy
import random
from faker import Faker
from datetime import date

fake = Faker()

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://root:root@localhost:5432/store"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db=SQLAlchemy(app)

@app.route("/user" , methods=["POST" , "GET"])
def users():
    if request.method ==  "GET" : 
        result=Users.query.all()
        user=[]
        for row in result:
            
            user={
                "id": row.id,
                "firstname":row.firstname,
                "lastname":row.lastname,
                "age": row.age,
                "email": row.email,
                "job": row.job}
            
            users.append(user)
        

        return jsonify(users)



class Users(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    firstname = db.Column(db.String(100))
    lastname=db.Column(db.String(100))
    age = db.Column(db.String(200))
    job=db.Column(db.String(100))
    applications=db.relationship('Application')
    
    def __init__(self, firstname,lastname,age,email,job):
        self.firstname = firstname
        self.lastname = lastname
        self.age = age
        self.email = email
        self.job = job

class Application(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    appname = db.Column(db.String(100))
    username=db.Column(db.String(100))
    lastconnection= db.Column(db.TIMESTAMP(timezone=True))
    user_id=db.Column(db.Integer,db.ForeignKey("users.id"))
    
    def __init__(self, appname,username,lastconnection):
        self.appname = appname
        self.username = username
        self.lastconnection = lastconnection

def populate_tables():
    apps = ["Facebook", "Instagram","Twitter", "Airbnb", "TikTok"]
    for n in range(0,1000):
        firstname = fake.first_name()
        lastname = fake.last_name()
        age = random.randrange(18, 50)
        email = fake.email()
        job = fake.job()
        
        new_user = Users(firstname, lastname, age,email , job)

       
        applications=[]
        x=random.randrange(1,4)
        nb_app=2
        
        for i in range(x):
            app_name=random.choice(apps)
            username=fake.user_name()
            last_connection=date.today()
            new_app= Application(app_name, username, last_connection)
            username = fake.username()
            applications.append(new_app)
            
       
            
        new_user.applications=applications
        
        db.session.add(new_user)
    db.session.commit()

if __name__ == '__main__':
    db.drop_all()
    db.create_all()
    populate_tables()
    app.run(host="0.0.0.0", port=8080, debug=True)

