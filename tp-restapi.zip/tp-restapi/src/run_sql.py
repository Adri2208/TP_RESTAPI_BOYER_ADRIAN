from sqlalchemy import create_engine

db_string = "postgresql://root:root@localhost:5432/store"

engine= create_engine(db_string)

connection = engine.connect()

#Create

with open("Create_table.sql", "r") as f:
    connection.execute(f.read())



